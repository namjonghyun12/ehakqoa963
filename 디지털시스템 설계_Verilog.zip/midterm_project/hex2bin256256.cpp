
#include "stdafx.h"
#include <iostream>
#include <fstream>

#define MAX_X 256
#define MAX_Y 256

using namespace std;

int main(int argc, char**argv) {
	char in_data[MAX_Y][MAX_X];

	char ch;
	ifstream inhex(argv[1], ios::in);
	ofstream out(argv[2], ios::out | ios::binary);
	

	int i, j;
	
	short data;
	for (i = 0; i < MAX_Y; i++) {
		for (j = 0; j < MAX_X; j++) {
			
			inhex >> hex >> data;
			in_data[i][j] = (char)(data);
		}
	}
	
	for (i = 0; i < MAX_Y; i++) {
		for (j = 0; j < MAX_X; j++) {
			out.put(in_data[i][j]);
			
		}
	}
	return 0;
}


