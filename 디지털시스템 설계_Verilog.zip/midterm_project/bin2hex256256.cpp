
#include <iostream>
#include <fstream>

#define MAX_X 256
#define MAX_Y 256

using namespace std;

int main(int argc) {
	char in_data[MAX_Y][MAX_X];

	char ch;
	ifstream in("d:GIRL", ios::in | ios::binary);
	ofstream outhex("d:GIRL", ios::out);

	int i, j;
	for (i = 0; i < MAX_Y; i++) {
		for (j = 0; j < MAX_X; j++) {
			in.get(ch);
			in_data[i][j] = ch;
		}
	}


	short mask = 0x00ff;
	short data;
	for (i = 0; i < MAX_Y ; i++) {
		for (j = 0; j < MAX_X; j++) {
			data = mask & (short)(in_data[i][j]);
			outhex << hex<< data <<'\n';
		} 
	}
	
	return 0;
}


